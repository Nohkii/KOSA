package day12;

public class LinkedListLab1 {

}

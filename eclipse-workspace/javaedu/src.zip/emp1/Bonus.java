package emp1;

public interface Bonus {
 void incentive(int pay);
}

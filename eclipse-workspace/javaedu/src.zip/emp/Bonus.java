package emp;

public interface Bonus {
	// public abstract는 생략해도 자동으로 붙음
	void incentive(int pay);
}

package day11;
public class ExceptionTest1 {
	public static void main(String[] args) throws Exception{
		System.out.println("수행시작");
		Thread.sleep(5000);
		System.out.println("수행종료");
		System.out.println();
	}
}

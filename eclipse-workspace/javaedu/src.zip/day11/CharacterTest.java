package day11;

public class CharacterTest {

	public static void main(String[] args) {
		System.out.println(Character.toLowerCase('A'));
		System.out.println(Character.toUpperCase('a'));
		System.out.println(Character.isDigit('A'));
		System.out.println(Character.isDigit('1'));
		System.out.println(Character.isLowerCase('A'));
		System.out.println(Character.isUpperCase('A'));
		System.out.println(Character.isSpaceChar(' '));		
	}
}

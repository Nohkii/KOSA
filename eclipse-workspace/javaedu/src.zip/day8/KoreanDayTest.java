package day8;

public class KoreanDayTest {
	public static void main(String[] args) {
		System.out.print("오늘은 ");
		System.out.print(KoreanDay.day);
		System.out.println("입니다.");
	}
}

package day10.case1;
public class TVUser {
	public static void main(String[] args) {
		SamsungTV tv = new SamsungTV();
		tv.powerOn();
		tv.volumnUp();
		tv.volumnDown();
		tv.powerOff();
		// 삼성티비에서 엘지티비로 바꿔주세요~ 요청하면 메소드도 다 바꿔야함
		// 메소드 이름 표준화(규격화)의 필요성
	
	}
}

package shop;
public interface Rentable {
	// interface는 상수와 추상메서드만 가질 수 있기 때문에 abstract가 자동으로 붙지만,,
	// 까먹지말고 꼭 붙이자,,,!^^
	public void rent();
}

//package collection;
//import java.util.Collection;
//import java.util.Comparator;
//import java.util.LinkedList;
//public class ProductTest4 {
//	public static void main(String[] args) {
//		LinkedList<Product2> product2 = new LinkedList<>();
//		product2.add(new Product2("p100","TV","20000"));
//		product2.add(new Product2("p200","Computer","10000"));
//		product2.add(new Product2("p100","MP3","700"));
//		product2.add(new Product2("p300","Audio","1000"));
//		product2.sort(product2);
//		The method sort(Comparator<? super Product2>) in the type List<Product2> 
//		is not applicable for the arguments (LinkedList<Product2>)
//	}
//}

package day1;
public class Exercise1 {
	public static void main(String[] args) {
		int n1 = 10;
		int n2 = 25;
		int n3 = 33;
		int sum = n1 + n2 +n3;
		int avg = sum/3;
		System.out.printf("합계 : %d\n평균 : %d",sum,avg);
	}
}
package day1;
public class Exercise2 {
	public static void main(String[] args) {
		int n1 = 35;
		int n2 = 10;
		System.out.printf("%d를 %d으로 나눈 결과 몫은 %d 이고 나머지는 %d 입니다.", n1, n2, n1/n2, n1%n2);
	}
}
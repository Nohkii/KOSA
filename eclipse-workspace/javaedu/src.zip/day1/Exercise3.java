package day1;
public class Exercise3 {
	public static void main(String[] args) {
		char name1 = '노';
		char name2 = '은';
		char name3 = '기';
		System.out.printf("%c%c%c", name1, name2, name3);
	}
}
package day7;
	public class Card{	
		String kind ;		// 카드의 무늬 - 인스턴스 변수
		 int number;		// 카드의 숫자 - 인스턴스 변수
		static int width = 100;	// 카드의 폭   - 클래스 변수 -> 명시적 초기화 (아예 값을 넣어버리는 것)
		static int height = 250;	// 카드의 높이 - 클래스 변수

	}
